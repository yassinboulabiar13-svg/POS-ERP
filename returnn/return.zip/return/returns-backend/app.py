"""
returns-backend/app.py

Module: Retours & Remboursements
- SQLite via SQLAlchemy (pos_returns.db)
- Endpoints:
  - /health
  - /articles (seeded)
  - /sales (seeded sale records) - used as preuve d'achat
  - /returns/initiate  (create return request)
  - /returns/<id>      (get return request)
  - /returns/inspect   (inspect by cashier)
  - /returns/validate  (responsable validation)
  - /returns/complete  (execute remboursement / avoir)
  - /returns/list
  - /movements
  - /admin/force_sync

Business rules included (délai de retour, validation seuil, reintegration stock, ERP queue)
"""

import os
from datetime import datetime, timedelta, timezone
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "pos_returns.db")

# Configuration business rules
DEFAULT_RETURN_DAYS = int(os.environ.get("RETURN_DAYS", "30"))           # délai retour en jours
VALIDATION_THRESHOLD_DT = float(os.environ.get("VALIDATION_THRESHOLD", "50.0"))  # montant requiring Responsable
ERP_SYNC_RETRY_MAX = 3

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{DB_PATH}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


# -----------------------
# Models
# -----------------------
class Article(db.Model):
    __tablename__ = "articles"
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(64), unique=True, nullable=False)
    name = db.Column(db.String(200), nullable=False)
    price = db.Column(db.Float, nullable=False, default=0.0)
    quantity = db.Column(db.Integer, nullable=False, default=0)  # local stock


class Sale(db.Model):
    __tablename__ = "sales"
    id = db.Column(db.Integer, primary_key=True)
    sale_number = db.Column(db.String(80), unique=True, nullable=False)
    customer_name = db.Column(db.String(200), nullable=True)
    total_amount = db.Column(db.Float, nullable=False, default=0.0)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))


class SaleItem(db.Model):
    __tablename__ = "sale_items"
    id = db.Column(db.Integer, primary_key=True)
    sale_id = db.Column(db.Integer, db.ForeignKey("sales.id"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id"), nullable=False)
    qty = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    sale = db.relationship("Sale", backref="items")
    article = db.relationship("Article")


class ReturnRequest(db.Model):
    __tablename__ = "returns"
    id = db.Column(db.Integer, primary_key=True)
    sale_number = db.Column(db.String(80), nullable=False)   # preuve d'achat
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id"), nullable=False)
    qty = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(300), nullable=True)
    status = db.Column(db.String(50), nullable=False, default="initiated")  # initiated / inspected / validated / refused / completed
    inspector_notes = db.Column(db.String(500), nullable=True)
    amount = db.Column(db.Float, nullable=False, default=0.0)  # montant à rembourser
    compensation = db.Column(db.String(20), nullable=True)  # 'refund' or 'credit'
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    validated_by = db.Column(db.String(120), nullable=True)
    article = db.relationship("Article")


class StockMovement(db.Model):
    __tablename__ = "movements"
    id = db.Column(db.Integer, primary_key=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id"), nullable=False)
    qty = db.Column(db.Integer, nullable=False)  # positive = in, negative = out
    reason = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    article = db.relationship("Article")


class ERPQueue(db.Model):
    __tablename__ = "erp_queue"
    id = db.Column(db.Integer, primary_key=True)
    payload = db.Column(db.Text, nullable=False)
    attempts = db.Column(db.Integer, nullable=False, default=0)
    last_error = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))


# -----------------------
# Helpers
# -----------------------
def now_utc():
    return datetime.now(timezone.utc)


def create_sample_data():
    # seed only if empty
    if Article.query.count() == 0:
        a1 = Article(sku="SKU-TSH-001", name="T-shirt bleu", price=25.0, quantity=15)
        a2 = Article(sku="SKU-PANT-001", name="Pantalon noir", price=70.0, quantity=7)
        a3 = Article(sku="SKU-JACK-001", name="Veste", price=120.0, quantity=4)
        db.session.add_all([a1, a2, a3])
        db.session.commit()
        print("Seeded articles.")

    if Sale.query.count() == 0:
        s1 = Sale(sale_number="INV-1001", customer_name="Amine", total_amount=95.0, created_at=now_utc() - timedelta(days=5))
        db.session.add(s1)
        db.session.commit()
        it1 = SaleItem(sale_id=s1.id, article_id=1, qty=1, unit_price=25.0)
        it2 = SaleItem(sale_id=s1.id, article_id=2, qty=1, unit_price=70.0)
        db.session.add_all([it1, it2])
        db.session.commit()
        print("Seeded sale INV-1001.")

    db.session.commit()


def find_sale_by_number(sale_number):
    return Sale.query.filter_by(sale_number=sale_number).first()


def sale_contains_article(sale, article_id, qty_requested):
    s = db.session.query(func.sum(SaleItem.qty)).filter(SaleItem.sale_id == sale.id, SaleItem.article_id == article_id).scalar() or 0
    return int(s) >= qty_requested


def within_return_window(sale):
    cutoff = now_utc() - timedelta(days=DEFAULT_RETURN_DAYS)
    return sale.created_at >= cutoff


def enqueue_erp(payload_text):
    q = ERPQueue(payload=payload_text, attempts=0, created_at=now_utc())
    db.session.add(q)
    db.session.commit()


# -----------------------
# Initialization
# -----------------------
with app.app_context():
    db.create_all()
    create_sample_data()


# -----------------------
# Endpoints
# -----------------------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "time": now_utc().isoformat()}), 200


@app.route("/articles", methods=["GET"])
def list_articles():
    articles = Article.query.all()
    out = [{"id": a.id, "sku": a.sku, "name": a.name, "price": a.price, "quantity": a.quantity} for a in articles]
    return jsonify(out)


@app.route("/sales", methods=["GET"])
def list_sales():
    sales = Sale.query.order_by(Sale.created_at.desc()).limit(100).all()
    out = []
    for s in sales:
        out.append({
            "id": s.id, "sale_number": s.sale_number, "customer_name": s.customer_name,
            "total_amount": s.total_amount, "created_at": s.created_at.isoformat(),
            "items": [{"article_id": it.article_id, "qty": it.qty, "unit_price": it.unit_price} for it in s.items]
        })
    return jsonify(out)


@app.route("/returns/initiate", methods=["POST"])
def initiate_return():
    data = request.get_json() or {}
    sale_number = data.get("sale_number")
    article_id = data.get("article_id")
    qty = int(data.get("qty", 0))
    reason = data.get("reason", "")

    if not sale_number or not article_id or qty <= 0:
        return jsonify({"error": "sale_number, article_id and qty>0 required"}), 400

    sale = find_sale_by_number(sale_number)
    if not sale:
        return jsonify({"error": "sale_not_found"}), 404

    if not within_return_window(sale):
        return jsonify({"error": "return_window_expired", "allowed_days": DEFAULT_RETURN_DAYS}), 403

    if not sale_contains_article(sale, article_id, qty):
        return jsonify({"error": "sale_does_not_contain_article_or_qty"}), 409

    item = SaleItem.query.filter_by(sale_id=sale.id, article_id=article_id).first()
    if not item:
        return jsonify({"error": "sale_item_not_found"}), 404

    refund_amount = float(item.unit_price * qty)

    rr = ReturnRequest(
        sale_number=sale_number,
        article_id=article_id,
        qty=qty,
        reason=reason,
        amount=refund_amount,
        status="initiated",
        created_at=now_utc()
    )
    db.session.add(rr)
    db.session.commit()
    return jsonify({"result": "initiated", "return_id": rr.id, "refund_amount": refund_amount}), 201


@app.route("/returns/<int:return_id>", methods=["GET"])
def get_return(return_id):
    r = ReturnRequest.query.get_or_404(return_id)
    return jsonify({
        "id": r.id,
        "sale_number": r.sale_number,
        "article_id": r.article_id,
        "article_name": r.article.name,
        "qty": r.qty,
        "reason": r.reason,
        "status": r.status,
        "amount": r.amount,
        "compensation": r.compensation,
        "inspector_notes": r.inspector_notes,
        "validated_by": r.validated_by,
        "created_at": r.created_at.isoformat()
    })


@app.route("/returns/list", methods=["GET"])
def list_returns():
    rs = ReturnRequest.query.order_by(ReturnRequest.created_at.desc()).limit(200).all()
    out = []
    for r in rs:
        out.append({
            "id": r.id, "sale_number": r.sale_number, "article_id": r.article_id,
            "article_name": r.article.name, "qty": r.qty, "status": r.status,
            "amount": r.amount, "created_at": r.created_at.isoformat()
        })
    return jsonify(out)


@app.route("/returns/inspect", methods=["POST"])
def inspect_return():
    data = request.get_json() or {}
    rid = data.get("return_id")
    notes = data.get("inspector_notes", "")
    if not rid:
        return jsonify({"error": "return_id required"}), 400
    r = ReturnRequest.query.get(rid)
    if not r:
        return jsonify({"error": "return_not_found"}), 404

    r.inspector_notes = notes
    r.status = "inspected"
    db.session.commit()
    return jsonify({"result": "inspected", "return_id": r.id})


@app.route("/returns/validate", methods=["POST"])
def validate_return():
    data = request.get_json() or {}
    rid = data.get("return_id")
    action = data.get("action")
    validated_by = data.get("validated_by", "Responsable")
    notes = data.get("notes", "")

    if not rid or action not in ("approve", "refuse"):
        return jsonify({"error": "return_id and action in (approve,refuse) required"}), 400

    r = ReturnRequest.query.get(rid)
    if not r:
        return jsonify({"error": "return_not_found"}), 404

    if action == "refuse":
        r.status = "refused"
        r.validated_by = validated_by
        r.inspector_notes = (r.inspector_notes or "") + " | validation_notes: " + notes
        db.session.commit()
        return jsonify({"result": "refused", "return_id": r.id})

    r.status = "validated"
    r.validated_by = validated_by
    r.inspector_notes = (r.inspector_notes or "") + " | validation_notes: " + notes
    db.session.commit()
    return jsonify({"result": "validated", "return_id": r.id})


@app.route("/returns/complete", methods=["POST"])
def complete_return():
    data = request.get_json() or {}
    rid = data.get("return_id")
    compensation = data.get("compensation")
    reintegrate = bool(data.get("reintegrate_stock", False))
    refund_method = data.get("refund_method", None)

    if not rid or compensation not in ("refund", "credit"):
        return jsonify({"error": "return_id and compensation (refund|credit) required"}), 400

    r = ReturnRequest.query.get(rid)
    if not r:
        return jsonify({"error": "return_not_found"}), 404

    if r.amount > VALIDATION_THRESHOLD_DT and r.status != "validated":
        return jsonify({"error": "requires_responsable_validation", "threshold": VALIDATION_THRESHOLD_DT}), 403

    if r.status == "refused":
        return jsonify({"error": "return_already_refused"}), 400

    r.compensation = compensation
    r.status = "completed"
    r.validated_by = r.validated_by or "auto"
    db.session.add(r)

    if reintegrate:
        art = Article.query.get(r.article_id)
        if art:
            art.quantity = art.quantity + r.qty
            mv = StockMovement(article_id=art.id, qty=+r.qty, reason=f"return reintegration return_id:{r.id}", created_at=now_utc())
            db.session.add(mv)

    payload = {
        "return_id": r.id,
        "sale_number": r.sale_number,
        "article_id": r.article_id,
        "qty": r.qty,
        "amount": r.amount,
        "compensation": compensation,
        "reintegrate_stock": reintegrate,
        "timestamp": now_utc().isoformat()
    }
    enqueue_erp(str(payload))

    db.session.commit()
    return jsonify({"result": "completed", "return_id": r.id, "erp_sync_enqueued": True}), 200


@app.route("/movements", methods=["GET"])
def movements():
    mv = StockMovement.query.order_by(StockMovement.created_at.desc()).limit(200).all()
    out = []
    for m in mv:
        out.append({
            "id": m.id,
            "article_id": m.article_id,
            "article_name": m.article.name,
            "qty": m.qty,
            "reason": m.reason,
            "created_at": m.created_at.isoformat()
        })
    return jsonify(out)


@app.route("/admin/force_sync", methods=["POST"])
def admin_force_sync():
    processed = []
    failed = []
    q_items = ERPQueue.query.order_by(ERPQueue.created_at.asc()).limit(50).all()
    for q in q_items:
        try:
            q.attempts += 1
            processed.append(q.id)
            db.session.delete(q)
        except Exception as e:
            q.attempts += 1
            q.last_error = str(e)[:400]
            if q.attempts >= ERP_SYNC_RETRY_MAX:
                failed.append({"id": q.id, "error": q.last_error})
    db.session.commit()
    return jsonify({"processed": processed, "failed": failed})


# -----------------------
# Run
# -----------------------
if __name__ == "__main__":
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=5004, debug=debug_mode)

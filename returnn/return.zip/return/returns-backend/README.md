# returns-backend

Backend Flask – Module "Retours & Remboursements"

## Structure
- app.py (serveur Flask)
- pos_returns.db (auto-créé)
- requirements.txt

## Prérequis
- Python 3.10+
- pip

## Installation / lancement
1. Créer et activer un virtualenv :
   - Windows:
     python -m venv venv
     venv\Scripts\activate
   - macOS / Linux:
     python -m venv venv
     source venv/bin/activate

2. Installer dépendances :
   pip install -r requirements.txt

3. Lancer l'application :
   python app.py
   Serveur: http://0.0.0.0:5004

La DB `pos_returns.db` est créée et contient des articles et une vente d'exemple.

## Endpoints principaux
- GET `/health`
- GET `/articles`
- GET `/sales`
- POST `/returns/initiate`
- POST `/returns/inspect`
- POST `/returns/validate`
- POST `/returns/complete`
- GET `/returns/<id>`
- GET `/returns/list`
- GET `/movements`
- POST `/admin/force_sync`

## Paramètres
- `RETURN_DAYS` env var : délai de retour (default 30)
- `VALIDATION_THRESHOLD` env var : montant seuil pour validation Responsable (default 50.0)

## Tests rapides (curl)
Voir run-instructions.txt in parent folder.
